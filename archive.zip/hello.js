<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
var a = "aaaa"
=======
=======
>>>>>>> origin/master
=======
>>>>>>> 9ec6a43f1d02f2b337dd6b1867e73cbd54ca4bf8
var a = "a"
<<<<<<< HEAD
<<<<<<< HEAD
var b = "a"
=======
var b = "b"
>>>>>>> parent of facb698... Revert "1.1"
=======
var b = "b"
>>>>>>> parent of facb698... Revert "1.1"
<<<<<<< HEAD
<<<<<<< HEAD
>>>>>>> 9ec6a43f1d02f2b337dd6b1867e73cbd54ca4bf8
=======
>>>>>>> origin/master
=======
>>>>>>> 9ec6a43f1d02f2b337dd6b1867e73cbd54ca4bf8
